package apptriviaismaelss;
public class Jugador {
     private String nombre;
     private String alias;
     private int puntaje;
     private Categoria miCategoria;
     private int contPreg;
     private int[] preguntasAleatorias;
     private int indice;
     private int contSalirTurno;

    public Jugador(String nombre, String alias, int puntos, Categoria categoria) {
        this.nombre = nombre;
        this.alias = alias;
        this.puntaje = puntos;
        this.miCategoria= categoria;
        contPreg=1;
        preguntasAleatorias= new int[5];
        indice=0;
        contSalirTurno=0;
    }
     public String sumaPuntos(boolean respuesta){
         String correcto="Respuesta INCORRECTA";
         if (respuesta) {
             correcto="¡Respuesta CORRECTA!";
             puntaje+=10;
         }
         return correcto;
     }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getPuntaje() {
        return puntaje;
    }

    public void setPuntaje(int puntaje) {
        this.puntaje = puntaje;
    }

    public Categoria getMiCategoria() {
        return miCategoria;
    }

    public void setMiCategoria(Categoria miCategoria) {
        this.miCategoria = miCategoria;
    }

    public int getContPreg() {
        return contPreg;
    }

    public void setContPreg(int contPreg) {
        this.contPreg = contPreg;
    }
    public void sumarPregunta(){
        contPreg++;
    }
    public void numerosAleatorio() {
        for (int i = 0; i < preguntasAleatorias.length; i++) { 
            int rnd = (int)(Math.random() * 5);
            preguntasAleatorias[i] = rnd;
        }
        for (int j = 0; j < preguntasAleatorias.length; j++) { // creamos la primera variable para la comprobacion
            for (int k = 0; k < preguntasAleatorias.length; k++) {//creamos la segunda que hara la comprobacion
                if (preguntasAleatorias[j] == preguntasAleatorias[k] && j != k) {
                    int rnd = (int)(Math.random() * 5);
                    preguntasAleatorias[j] = rnd;
                    j = 0;
                }
            }
        }
    }
    public int numRandom(){
        int num=0;
        if (indice!=5) {
            num= preguntasAleatorias[indice];
            indice++;
        }else{
            indice=0;
            num=num= preguntasAleatorias[indice];
        }
        return num;
    }

    @Override
    public String toString() {
        StringBuilder sb= new StringBuilder("");
        sb.append(alias).append("\n").append("Categoría: ").append(miCategoria.toString()).append("\n").append("Puntuación:     ").append(puntaje);
        return sb+"";
    }
    
}
