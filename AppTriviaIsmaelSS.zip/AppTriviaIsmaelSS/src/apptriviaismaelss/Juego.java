package apptriviaismaelss;
public class Juego {
    private Pregunta preguntas[][];
    private Categoria categorias[];
    private Jugador jugadores[];
    private final int FIL=5;
    private final int COL=5;
    private int contjugadores;
    private int turno;
    private int numeroPregunta;
    private Jugador arrayAux[];
    public Juego() {
        this.preguntas = new Pregunta[FIL][COL];
        this.categorias = new Categoria[5];
        this.jugadores= new Jugador[10];
        //CREACION DE CATEGORIAS
        categorias[0]= new Categoria("DEP","Deportes");
        categorias[1]= new Categoria("TEC","Tecnología");
        categorias[2]= new Categoria("HIS","Historia");
        categorias[3]= new Categoria("RCR","Refranes costarricenses");
        categorias[4]= new Categoria("ECO","Ecología");
        //CREACION DE PREGUNTAS Y RESPUESTAS
        preguntas[0][0]= new Pregunta(1, "En el famoso Triatlón Ironman se llevan a cabo 3 tipos de disciplinas consecutivas, recorriendo distancias determinadas. ¿Cúales son estas disciplinas?", 3, "Baile, maratón y natación.", "Natación, senderismo y ciclismo.", "Natación, ciclismo y maratón.");
        preguntas[0][1]= new Pregunta(2, "¿Cuál es el largo de una piscina Olímpica según la Federación Internacional de Natación?", 1, "50 metros.", "75 metros.", "100 metros.");
        preguntas[0][2]= new Pregunta(3, "¿Cuántos cambios son permitidos en un partido de Basketball?", 3, "5", "3", "Todos los que se deseen");
        preguntas[0][3]= new Pregunta(4, "¿Cuánto dura cada asalto o round en el Boxeo Profesional Masculino?", 2, "Dos minutos.", "Tres minutos.", "Cinco minutos.");
        preguntas[0][4]= new Pregunta(5, "Usain Bolt es reconocido por un sobrenombre en inglés muy peculiar.¿Cúal es este sobrenombre?", 2, "Fast Bolt", "Lightning Bolt", "Flash Bolt");
        preguntas[1][0]= new Pregunta(1, "¿En qué año nace la World Wide Web (www)?", 1, "1991", "1998", "1995");
        preguntas[1][1]= new Pregunta(2, "¿Cómo se llamaba la mujer que en conjunto a su equipo desarrolló el software de navegación -on board- utilizado para el Programa Espacial Apolo?", 3, "Hedy Lamarr", "Marion Donovan", "Margaret Hamilton");
        preguntas[1][2]= new Pregunta(3, "¿Qué corporación es dueña actualmente de la reconocida aplicación de mensajería WHATSAPP?", 2, "Google Inc", "Facebook Inc", "Microsoft Inc");
        preguntas[1][3]= new Pregunta(4, "¿En qué año llega a suelo marciano el explorador CURIOSITY desarrollado por la Nasa?", 3, "2010", "2015", "2012");
        preguntas[1][4]= new Pregunta(5, "¿Cómo se llama el sistema númerico basado en: 1 y 0?", 1, "Binario", "Hexadecimal", "Bidecimal");
        preguntas[2][0]= new Pregunta(1, "¿En qué guerra participó Juana de Arco?", 1, "La Guerra de los 100 años", "La Guerra de los 30 años", "Primera cruzada");
        preguntas[2][1]= new Pregunta(2, "Capital del imperio Inca:", 3, "Machu Picchu", "Lima", "Cuzco");
        preguntas[2][2]= new Pregunta(3, "¿Quién fue el primer emperador romano?", 2, "Julio Cesar", "Cesar Augusto", "Nerón");
        preguntas[2][3]= new Pregunta(4, "Año en el que cae el Imperio Romano del occidente: ", 1, "476", "496", "456");
        preguntas[2][4]= new Pregunta(5, "¿Qué pais encabezaba Joseph Stalin?", 3, "Ucrania", "Russia", "Uniión Soviética");
        preguntas[3][0]= new Pregunta(1, "En casa de herrero...", 3, "...cuchara de palo", "...tenedor de metal", "...cuchillo de palo");
        preguntas[3][1]= new Pregunta(2, "A caballo regalado no se le busca...", 2, "...cola", "...colmillo", "...piojo");
        preguntas[3][2]= new Pregunta(3, "A Dios rogando y con el...", 3, "martillo dando", "mazo pegando", "mazo dando");
        preguntas[3][3]= new Pregunta(4, "El que con lobos anda...", 2, "a ladrar aprende", "a aullar aprende", "a morder aprende");
        preguntas[3][4]= new Pregunta(5, "Perro que come huevos, ni...", 3, "majándole el hocico aprende", "cortándole la cola aprende", "quemándole el hocico aprende");
        preguntas[4][0]= new Pregunta(1, "Ciencia que estudia la manera que interactúan los organismos entre sí y con su medio que los rodea así como la distribución y la abundancia:", 3, "Biología", "Química", "Ecología");
        preguntas[4][1]= new Pregunta(2, "Es la suma de todos los organismos que existen sobre el planeta y su ambiente:", 1, "Ecosistema", "Comunidad", "Biosfera");
        preguntas[4][2]= new Pregunta(3, "El modo de vida que un organismo lleva y su rol en la cadena alimenticia constituyen su:", 3, "Roll ambiental", "Función de un ser vivo", "Nicho Ecológico");
        preguntas[4][3]= new Pregunta(4, "La relación beneficiosa entre las aves o insectos polinizadores y las plantas correspondientes es un ejemplo de lo que se denomina:", 2, "Parasitismo", "Mutualismo", "Amensalismo");
        preguntas[4][4]= new Pregunta(5, "Un carnívoro que se alimenta de otro carnívoro, está en el ________ nivel trófico.", 1, "Cuarto", "Primer", "Tercero");
        //Precarga de 4 jugadores
        jugadores[0]=new Jugador("Britany", "Brix", 20, categorias[2]);
        jugadores[1]=new Jugador("Juan", "JuanGamer", 10, categorias[3]);
        jugadores[2]=new Jugador("David", "3max7070", 40, categorias[1]);
        jugadores[3]=new Jugador("Saraí", "Saridgy", 30, categorias[4]);
        contjugadores = 4;
        turno=4;
        numeroPregunta=0;
    }

    public Pregunta[][] getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(Pregunta[][] preguntas) {
        this.preguntas = preguntas;
    }

    public Categoria[] getCategorias() {
        return categorias;
    }

    public void setCategorias(Categoria[] categorias) {
        this.categorias = categorias;
    }

    public Jugador[] getJugadores() {
        return jugadores;
    }

    public void setJugadores(Jugador[] jugadores) {
        this.jugadores = jugadores;
    }

    public int getContjugadores() {
        return contjugadores;
    }

    public void setContjugadores(int contjugadores) {
        this.contjugadores = contjugadores;
    }    
    public String agregarJugadores(Jugador unJugador){
        if (contjugadores <= 9) {
            for (int i = 4; i < contjugadores; i++) {
                if (unJugador.getMiCategoria() == jugadores[i].getMiCategoria()) {
                    return "Categoría ya seleccionada por otro jugador, por favor seleccione una categoría distinta.";
                }
            }
           jugadores[contjugadores]=unJugador;
           contjugadores++;
           
           return "Jugador añadido éxitosamente";
        }else{
            return "Cupo de jugadores límite alcanzado";
        }
    }
    public Jugador turno(){
        Jugador miJugador=null;
        if (turno<contjugadores) {
            miJugador=jugadores[turno];
            turno++;
        }else{
                miJugador=jugadores[4];
                turno=5;
    }
        return miJugador;
    }
    public Pregunta preguntaRespuesta(Jugador unJugador){
        Pregunta unaPregunta=null;
        Categoria categoria= unJugador.getMiCategoria();
        numeroPregunta=unJugador.numRandom();
        for (int i = 0; i < categorias.length; i++) {
            if (categorias[i].equals(categoria)) {
                unaPregunta=preguntas[i][numeroPregunta];
                return unaPregunta;
            }
        }
        return unaPregunta;
    }
    public String resultadoFinalSalir_fin() {
        StringBuilder sb = new StringBuilder("");
        sb.append("----------Resultado-----------\n");
        arrayAux= new Jugador[contjugadores-4];
        int cont=5;
        for (int i = 0; i < arrayAux.length; i++) {
            if (jugadores[cont]!=null) {
                arrayAux[i]=jugadores[cont];
            }
            cont++;
        }
        //ordenar puntuaciones y dar ganador
        Jugador aux;
        for (int i = 0; i < arrayAux.length; i++) {
            int min=i;
            for (int j = i+1; j < arrayAux.length; j++) {
                if (arrayAux[j].getPuntaje()>arrayAux[min].getPuntaje()) {
                    min=j;
                }
            }
            if (i!=min) {
                aux=arrayAux[i];
                arrayAux[i]=arrayAux[min];
                arrayAux[min]=aux;
            } 
        }
        sb.append("Ganador: ").append(arrayAux[0].getAlias()).append("\nPuntuación: ").append(arrayAux[0].getPuntaje()).append("\n¡FELICIDADES!\nHAS PUESTO A PRUEBA TU CONOCIMIENTO Y HAS DEMOSTRADO SER EL MEJOR");
        
        return sb + "";
    }
    public String reglasDelJuego(){
        StringBuilder reglas= new StringBuilder("");
        reglas.append("Bienvenidos a TriviTK, donde pondran a prueba su conocimiento al máximo.\n").append("Para iniciar el juego es necesario que cada jugador sepa las reglas del juego.\n").append("Reglas:\n").append("1. El mínimo de jugadores es de 2 y su máximo es de 5 jugadores.\n").append("2. Existe la posibilidad de abandonar la partida en cualquier momento, sin embargo no formará parte de la tabla de puntuaciones\ncon las mejores 10 puntajes.\n").append("3. Cada respuesta  correcta tiene un valor de 10 puntos.\n").append("4. Solamente se realizaran 5 preguntas por jugador y se mostrará el resultado final.\n").append("5.Una vez se elije la categoría no se podrá cambiar por otra.\n").append("6. Un jugador no puede elegir la misma categoría que ya otro jugador haya preestablecido.\n Debe ser diferente, por lo cual existen 5 categorías distintas para que cada jugador pueda elegir una.\n").append("7. Puntuación máxima será de 50 puntos, la mínima 0.\n").append("Éxitos, disfruta nuestra Trivia.");
        return reglas+"";
    }
    public String estadisticas(){
        StringBuilder sb = new StringBuilder("");
        //ordenar puntuaciones de para la tabla de puntuaciones total
        Jugador aux;
        
        for (int i = 0; i < contjugadores; i++) {
            int min=i;
            for (int j = i+1; j < contjugadores; j++) {
                if (jugadores[j].getPuntaje()>jugadores[min].getPuntaje()) {
                    min=j;
                }
            }
            if (i!=min) {
                aux=jugadores[i];
                jugadores[i]=jugadores[min];
                jugadores[min]=aux;
            } 
        }
        for (int i = 0; i < jugadores.length; i++) {
            if (jugadores[i]!=null) {
                sb.append(i+1).append(". ").append(jugadores[i].toString()).append("\n-----------------------------------------------------\n");
            }
        }
        return sb+"";
    }
    public String imprimeArrayAux(){
        StringBuilder sb= new StringBuilder("");
        sb.append("Ganador: ").append(arrayAux[0].getAlias()).append("\nPuntuación: ").append(arrayAux[0].getPuntaje()).append("\n¡FELICIDADES!\nHAS PUESTO A PRUEBA TU CONOCIMIENTO Y HAS DEMOSTRADO SER EL MEJOR");
        return sb+"";
    }
}
