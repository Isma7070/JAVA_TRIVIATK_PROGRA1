package apptriviaismaelss;
public class Pregunta {
    private int numero;
    private String pregunta;
    private String respuestas[];
    private int posicionR;

    public Pregunta(int numero, String pregunta, int posicionR, String r1, String r2, String r3) {
        this.numero = numero;
        this.pregunta = pregunta;
        this.posicionR = posicionR;
        this.respuestas= new String[3];
        //Asignación de respuestas
        this.respuestas[0]= "\n"+r1;
        this.respuestas[1]="\n"+ r2;
        this.respuestas[2]= "\n"+r3;
    }
    public boolean respuestaCorrecta(int respuesta){
        if (respuesta == posicionR ) {
            return true;
        }
        return false;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String[] getRespuestas() {
        return respuestas;
    }

    public void setRespuestas(String[] respuestas) {
        this.respuestas = respuestas;
    }

    public int getPosicionR() {
        return posicionR;
    }

    public void setPosicionR(int posicionR) {
        this.posicionR = posicionR;
    }

    @Override
    public String toString() {
        StringBuilder sb= new StringBuilder("");
        sb.append(pregunta).append("\nA").append(respuestas[0]).append("\nB").append(respuestas[1]).append("\nC").append(respuestas[2]);
        return sb+"";
    }
    
}
